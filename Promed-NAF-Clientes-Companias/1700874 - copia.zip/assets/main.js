const btnAuthorizeDni = document.querySelector("button[id='getDni']");
const btnAuthorizeLoc = document.querySelector("button[id='getLoc']");
// Zendesk
const cliente = ZAFClient.init();
//cliente.invoke('resize', { width: '20vw', height: '50vh' });
cliente.invoke('resize', { width: '300px', height: '450px'});

// Vbles de entorno
var tipoConsulta = "1";
var dni_tipo = "dni";
var dni_nro = "0";
var localizador = "";
var selectTipo = document.getElementById("docType");
//Para la consulta de los datos
var miStatus='';
var miAccessToken = 'valor-inicial';
var miCokieJSESSIONID = 'valor-inicial';

hideAlerts();

btnAuthorizeDni.addEventListener("click", function(){
	//login('1',cliente,'');
	tipoConsulta = "1";
	dni_tipo = selectTipo.options[selectTipo.selectedIndex].value;
	dni_nro = document.getElementById("dni").value;
	console.log('Tipo y Nro. de DNI: ' + dni_tipo + '-' + dni_nro);
	autoriza();
	
})

btnAuthorizeLoc.addEventListener("click", function(){
	//login('1',cliente,'');
	tipoConsulta = "2";
	localizador = document.getElementById("locator").value;
	console.log('Localizador: ' + localizador);
	autoriza();
	
})

function hideAlerts(){

	$("#okAlert").fadeOut();
	$("#errorAlert").fadeOut();
};


function autoriza(){
	//window.alert('Llegue!...');
	//calculo el token para le Authoriza
	//---Dypsa
	//Solicito la Cookie a MV de Dypsa-ho2.sisdypsa.com.ar
	var options = {
		url: "http://ho2.sisdypsa.com.ar:443/api-voyenbus/voyenbus/",
  		type: "GET",
  		cors: false,
		headers: {
			"Authorization": "Token dd80ae0dbd20a434fce0cb74353e7ae6f3f55a5b",
			"Cookie": "XSRF-TOKEN=eyJpdiI6IjB5ajBTeUQ3QVNVd2F3RVlZTzZcL0xRPT0iLCJ2YWx1ZSI6Ik9VZnV2VHN5b0FyTTVjeTRvaFNNUVwvYlcra0d0R2VHZEl2b256cW5jejVYMnNobnh4V2x3UUprQWt0bkpkSXdVYlRIMUlqOXlKOEtsXC9EU2Z5bU8yTjJWNGc4cWRVVExsdjhjWG9VR3puUnkxZnpIN0wzTlNXWmhJQ1M1WXcxK3UiLCJtYWMiOiJiODg1YjFjZWNkOTI1NDdjNjllNDNmMjQ5ZTZlOWI3MTU5NjIwMjkwZDgxMDYxZjk3MGMxMzM0NWQxYWE3NzE3In0%3D; snipeit_session=zQv8Hvtnd7tXJOUAqHJVqjLKgxZREA54btOz7AFs"
		  },
	};
	cliente.request(options).then((response) => {
		console.log(JSON.stringify(response));
		var x = JSON.stringify(response);
		miStatus = response.results[0].Status;
		console.log(miStatus);	
		miAccessToken = response.results[0].AccessToken;
		console.log(response.results[0].AccessToken);
		miCokieJSESSIONID = 'JSESSIONID='  + response.results[0].Jssessionid;
		console.log(miCokieJSESSIONID);
		console.log(response.results[0].Updated);
		//Llamo a las API's de Voyenbus si el response=OK
		if (miStatus == "OK"){
			//Llamo a LOGIN
			login();
		} else {
			$("#errorAlert").fadeIn();
		}
	});
}



function login(){
	
	console.log('ENTRO AL LOGIN OCN:')
	console.log('access_token: ' + miAccessToken);
	console.log('cookie: ' + miCokieJSESSIONID);
	//Paso el response a JSON para obtener el atoken
	const payload = JSON.stringify({
		  "User": {
			"username": "zendesk",
			"password": "Asc892nCiwl"
		  }
		});
	var options2 = {
		url: "https://api009.buses.global/TOLWeb/api/rest/v1.0/bo/login",
		type: "POST",
		contentType: 'application/json',
		headers: {
		  Authorization: miAccessToken,
		  VEBOrigin: "ticketonline.zendesk.com",
		  VEBCookie: miCokieJSESSIONID,
		},
		  data: payload,
		};
	  
	  //$.ajax(settings).done(function (response) {
	  //	console.log(response);
	  //});
	  cliente.request(options2)
	  	.then(function(response) {
			console.log('LOGIN');
			console.log(JSON.stringify(response));
			console.log('Tipo de Consulta: ' + tipoConsulta);
			hideAlerts();
			displayVacio('');
			//Habilito la consulta segun tipo: 1-Tipo y Nro DNI, 2-Localizador
			if (tipoConsulta == '1'){
				persons();
			}
			else {
				sales();
			}
		},
	  function(response) {
		console.log('ERROR LOGIN:');
		console.log(JSON.stringify(response));
		displayVacio(response.status);
		$("#errorAlert").fadeIn();
		//
	  });
}


function persons(){
	console.log('Tipo de Consulta: ' + tipoConsulta);
	//Paso el response a JSON para obtener el atoken
	const payload = JSON.stringify({
		"personFind": {
			"frontConfig": {
			  "pagNumber": 0,
			  "pagSize": 100,
			  "activePaginator": true
			},
			"genericSearch": "",
			"personApi": {
			  "idTypeCode": dni_tipo,
			  "idNumber": dni_nro,
			  "email": ""
			}
		  }
	  });
  const options = {
	  url: "https://api009.buses.global/TOLWeb/api/rest/v1.0/bo/person/search",
	  type: "POST",
	  contentType: 'application/json',
	  headers: {
		Authorization: miAccessToken,
		VEBOrigin: "ticketonline.zendesk.com",
		VEBCookie: miCokieJSESSIONID
	  },
		data: payload,
	  };
	cliente.request(options)
		.then(function(response) {
		  console.log('PERSONS');
		  console.log(JSON.stringify(response));
		  displayPersonas(response);
		  $("#okAlert").fadeIn();
	  },
	function(response) {
	  console.log('ERROR PERSONS:');
	  console.log(JSON.stringify(response));
	  displayVacio(response.status);
	  $("#errorAlert").fadeIn();
	});

}

function sales(){
	console.log('Tipo de Consulta: ' + tipoConsulta);
	//Paso el response a JSON para obtener el atoken
	const payload = JSON.stringify({
		"filters": {
			"locator": localizador,
			"initialDate": "2023-01-01T01:00:00.000Z",
			"finalDate": "2023-12-31T23:59:59.059Z",
			"frontConfig": {
				"pagNumber": 0,
				"pagSize": 100,
				"activePaginator": true
			},
			"email": "",
			"ticket": "",
			"document": ""
		}
	 });
  const options = {
	  url: "https://api009.buses.global/TOLWeb/api/rest/v1.0/bo/sales/find",
	  type: "POST",
	  contentType: 'application/json',
	  headers: {
		Authorization: miAccessToken,
		VEBOrigin: "ticketonline.zendesk.com",
		VEBCookie: miCokieJSESSIONID
	  },
		data: payload,
	  };
	cliente.request(options)
		.then(function(response) {
		  console.log('SALES');
		  console.log(JSON.stringify(response));
		  if (Object.entries(response.data.sales).length !== 0){
			displayLoc(response);
			$("#okAlert").fadeIn();
		  } else {
			displayLocSINsales(response);
			$("#okAlert").fadeIn();
		  }
	  },
	function(response) {
	  console.log('ERROR SALES:');
	  console.log(JSON.stringify(response));
	  displayVacio(response.status);
	  $("#errorAlert").fadeIn();
	});
}
//
//---- VISUALIZACION DE DATOS
//
function displayVacio(codoperacion){
	document.getElementById('idNumber').style.display="";
	document.getElementById('idNumber').innerHTML="";
	document.getElementById('lastname').style.display="";
	document.getElementById('lastname').innerHTML="";	
	document.getElementById('name').style.display="";
	document.getElementById('name').innerHTML="";	
	document.getElementById('phone').style.display="";
	document.getElementById('phone').innerHTML="";
	document.getElementById('email').style.display="";
	document.getElementById('email').innerHTML="";
	document.getElementById('id').style.display="";
	document.getElementById('id').innerHTML="";
	document.getElementById('status-op').style.display="";
	document.getElementById('status-op').innerHTML=codoperacion;
	// Agrego el set de campos del ticket
	//
	//Localizador
	cliente.set('ticket.customField:custom_field_360039339031', '');
	//Telefono
	cliente.set('ticket.customField:custom_field_360039406632', '');
	//Correo
	//client.set('ticket.customField:custom_field_360048354551', '');
	//Apellido y Nombre
	cliente.set('ticket.customField:custom_field_1900001995767', '');	
}

//------ PERSONS
function displayPersonas(jasonres){
	document.getElementById('idNumber').style.display="";
	document.getElementById('idNumber').innerHTML=jasonres.data.list[0].idTypeCode + '-' + jasonres.data.list[0].idNumber;
	document.getElementById('lastname').style.display="";
	document.getElementById('lastname').innerHTML=jasonres.data.list[0].lastname;	
	document.getElementById('name').style.display="";
	document.getElementById('name').innerHTML=jasonres.data.list[0].name;	
	document.getElementById('phone').style.display="";
	document.getElementById('phone').innerHTML=jasonres.data.list[0].phones;
	document.getElementById('email').style.display="";
	//document.getElementById('email').innerHTML=jasonres.data.list[0].emails[Object.entries(jasonres.data.list[0].emails).length - 1];
	document.getElementById('email').innerHTML=jasonres.data.list[0].email;
	document.getElementById('id').style.display="";
	document.getElementById('id').innerHTML="";
	document.getElementById('status-op').style.display="";
	document.getElementById('status-op').innerHTML=jasonres.status;
	// Agrego el set de campos del ticket
	var xname = jasonres.data.list[0].lastname + ',' + jasonres.data.list[0].name;
	//
	//Localizador
	cliente.set('ticket.customField:custom_field_360039339031', '');
	//Telefono
	cliente.set('ticket.customField:custom_field_17247464139540', jasonres.data.list[0].phones);
	//Correo
	//client.set('ticket.customField:custom_field_360048354551', '');
	//Apellido y Nombre
	cliente.set('ticket.customField:custom_field_17125275174036', jasonres.data.list[0].name + ' ' + jasonres.data.list[0].lastname );	
	//Solicitante
	cliente.set('ticket.requester',  { "name": xname, "email": jasonres.data.list[0].email });	

}

//---- LOCALIZADOR
function displayLoc(jasonres){
	$("#okAlert").fadeIn();
	document.getElementById('idNumber').style.display="block";
	document.getElementById('idNumber').innerHTML=jasonres.data.sales[0].payer.idNumber;
	document.getElementById('lastname').style.display="block";
	document.getElementById('lastname').innerHTML=jasonres.data.sales[0].payer.lastname;	
	document.getElementById('name').style.display="block";
	document.getElementById('name').innerHTML=jasonres.data.sales[0].payer.name;	
	document.getElementById('phone').style.display="block";
	document.getElementById('phone').innerHTML=jasonres.data.sales[0].payer.phone;
	document.getElementById('email').style.display="block";
	//document.getElementById('email').innerHTML=jasonres.data.sales[0].payer.emails[Object.entries(jasonres.data.sales[0].payer.emails).length - 1];
	document.getElementById('email').innerHTML=jasonres.data.sales[0].payer.email;
	document.getElementById('id').style.display="block";
	//document.getElementById('id').innerHTML=jasonres.data.sales[0].locator;
	document.getElementById('id').innerHTML=localizador;
	document.getElementById('status-op').style.display="block";
	document.getElementById('status-op').innerHTML=jasonres.status;
	// Agrego el set de campos del ticket
	//
	var xname = jasonres.data.sales[0].payer.lastname + ',' + jasonres.data.sales[0].payer.name;
	//Localizador
	cliente.set('ticket.customField:custom_field_360039339031', '');
	//Telefono
	cliente.set('ticket.customField:custom_field_17247464139540', jasonres.data.sales[0].payer.phone);
	//Correo
	//client.set('ticket.customField:custom_field_360048354551', '');
	//Apellido y Nombre
	cliente.set('ticket.customField:custom_field_17125275174036', jasonres.data.sales[0].payer.name + ' ' + jasonres.data.sales[0].payer.lastname );	
	//Solicitante
	cliente.set('ticket.requester',  { "name": xname, "email": jasonres.data.sales[0].payer.email });	
}

function displayLocSINsales(jasonres){
	$("#okAlert").fadeIn();
	document.getElementById('idNumber').style.display="block";
	document.getElementById('idNumber').innerHTML="No SALES";
	document.getElementById('lastname').style.display="block";
	document.getElementById('lastname').innerHTML="No SALES";	
	document.getElementById('name').style.display="block";
	document.getElementById('name').innerHTML="No SALES";	
	document.getElementById('phone').style.display="block";
	document.getElementById('phone').innerHTML="No SALES";
	document.getElementById('email').style.display="block";
	document.getElementById('email').innerHTML="No SALES";
	document.getElementById('id').style.display="block";
	//document.getElementById('id').innerHTML=jasonres.data.sales[0].locator;
	document.getElementById('id').innerHTML=localizador;
	document.getElementById('status-op').style.display="block";
	document.getElementById('status-op').innerHTML=jasonres.status;
	// Agrego el set de campos del ticket
	//
	//Localizador
	cliente.set('ticket.customField:custom_field_360039339031', localizador);
	//Telefono
	cliente.set('ticket.customField:custom_field_17247464139540', '');
	//Correo
	//client.set('ticket.customField:custom_field_360048354551', 'lucas@voyenbus.com');
	//Apellido y Nombre
	cliente.set('ticket.customField:custom_field_17125275174036', '');		
}
